# uft-one-ai-sap-fiori-va01-s4hana
This UFT One script leverages AI to run tcode va01 on the fiori S/4 HANA interface.
